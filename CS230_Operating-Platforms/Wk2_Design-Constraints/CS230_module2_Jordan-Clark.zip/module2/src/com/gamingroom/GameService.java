package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	
	/*
	 *  Store the instance of the GameService in the variable service if
	 *  the service doesn't already exist.
	 */
	private static GameService service = null;
	
	/** 
	 * Singleton Implementation
	 */
	// The private empty constructor prevents direct calls with 'new' operator
	private GameService() {
	}
	
	// The static method controls public access to the GameService instance
	
	public static GameService getInstance() {
		// Check to see if an instance of GameService already exists
		// If there isn't an existing game
		if (service == null) {
			// Create a new one
			service = new GameService();
		}
		
		// If there is an existing game, return only that one.
		return service;
	}

	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		/**
		 * Iterator Pattern
		 */
		// Iterate through Games to look for existing game with same name
		if (getGame(name) != null) {
			// if game exists, return it.
			game = getGame(name);
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		/**
		 * Iterator Pattern
		 */
		// Iterates through games to look for existing game with same id
		for (int i = 0; i < getGameCount(); i++) {
			if (games.get(i).getId() == id) {
				game = games.get(i);
			}
		}
		
		// if found, simply assign that instance to the local variable
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		/**
		 * Iterator Pattern
		 */
		// Iterates through games to look for existing game with the same name
		for (int i = 0; i < getGameCount(); i++) {
			if (games.get(i).getName() == name) {
				game = games.get(i);
			}
		}
		
		// if found, simply assign that instance to the local variable
		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
